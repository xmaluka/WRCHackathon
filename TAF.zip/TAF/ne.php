<html>
<body>
<?php
$s='start';
$output = passthru("python hj.py ".$s);
echo $output;
?>
</body>
</html>
