
print($s)